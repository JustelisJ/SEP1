import java.util.ArrayList;

public class Workschedule {
   private Date date;
   private ArrayList<Vacation> vacation;
   private ArrayList<Shift> shift;
   private double weekSumHours;
   
   //not implemented
}
